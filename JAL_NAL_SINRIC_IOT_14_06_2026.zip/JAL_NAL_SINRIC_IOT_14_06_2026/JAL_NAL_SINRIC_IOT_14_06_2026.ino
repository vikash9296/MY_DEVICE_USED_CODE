/*
  PumpController_Final_Fresh_BY_VIKASH_KUMAR_01_01_2026
  --------------------------------------------------
  COMPLETELY SAME LOGIC + SAME UI + SAME COLOR
  FIXED: Local WiFi AP Stability (Always ON Fix)
  FIXED: Auto Mode 60 Sec Delay restored.

  ONLY ADD:
  1) Nearby WiFi dropdown (optional)
  2) Relay trigger time 1–5 sec (optional, default 2s)

  NOTHING REMOVED / NOTHING CHANGED
*/

#include <WiFi.h>
#include <WebServer.h>
#include <Preferences.h>
#include <ArduinoOTA.h>
#include <SinricPro.h>
#include <SinricProSwitch.h>
#include <DNSServer.h>

// ------------------- Sinric Pro Credentials -------------------
#define APP_KEY       "fde635b4-5eca-42be-8552-ab61a5cebaea"
#define APP_SECRET    "433a590a-4aed-4364-aec1-9e08cd186997-3ff8f48f-0ba7-4cd7-b3c9-1c189ef8d135"
#define DEVICE_ID_1   "6a2e0b4629c6be33425f16fe"
#define DEVICE_ID_2   "6a2e0b6f6ba33a80b978a171"
#define DEVICE_ID_3   "6a2e0b99969af7ec2452ffb3"

// ------------------- Pins -------------------
#define RELAY1_PIN      19  // START RELAY NAME IN SINRIC APP MOTOR
#define RELAY2_PIN      21  // STOP RELAY NAME IN SIRIC APP PUMP
#define AUTO_MODE_LED   22  // AUTO MODE ON AND OFF INTERNALLY USE IN SINRIC NAME AUTO MODE
#define WIFI_LED_PIN    2   // FOR WIFI STATUS LED
#define MANUAL_BTN_PIN  27  // FOR WATER FLOAT SENSOR WHEN WATER TANK OVERFLOWW PUMP OFF AUTOMATICALLY
#define AUTO_TOGGLE_BTN 23  // AUTO MODE ON AND OFF MANNUALY TO GROUND PUSH BUTTON
#define BOOT_BTN_PIN    0   // SYSTEM RESET DEFAULT WIFI SSID PASSWORD

// ------------------- Constants -------------------
#define HOLD_TIME       3000  // FLOAT SENSOR DELAY TIME
#define PULSE_TIME      2000  // RELAY TRIGGER DEFAULT TIME IN SECOND
#define AUTO_DELAY      60000 // PUMP ON DELAY TIME IN AUTO MODE ENABLE
#define DNS_PORT        53
#define WIFI_RETRY_MS   5000  // WIFI RECONNECT TRY EVERY 5SECOND

// ------------------- Defaults -------------------
const char* DEFAULT_AP_NAME = "PumpController_AP";
const char* DEFAULT_AP_PASS = "12345678";

// ------------------- Globals -------------------
Preferences preferences;
WebServer server(80);
DNSServer dnsServer;

bool autoMode = false;
bool btnPressed = false;
bool bootBtnPressed = false;
bool apModeActive = false;

unsigned long btnPressStart = 0;
unsigned long bootBtnStart = 0;
unsigned long lastReconnectAttempt = 0;

String wifi_ssid = "";
String wifi_pass = "";
String ap_name = "";
String ap_pass = "";

// --------- ADDED (SAFE DEFAULTS) ---------
int relayPulseMs = PULSE_TIME;   // default = 2000 ms
int wifiScanCount = 0;

// Stable AP IP Settings
IPAddress apIP(192, 168, 4, 1);
IPAddress netMsk(255, 255, 255, 0);
// ----------------------------------------

// ================= Helper =================
bool isIp(String str) {
  for (unsigned int i = 0; i < str.length(); i++) {
    int c = str.charAt(i);
    if (c != '.' && (c < '0' || c > '9')) return false;
  }
  return true;
}

// ================= Relay Control =================
void setupRelay(int pin) {
  pinMode(pin, OUTPUT);
  digitalWrite(pin, HIGH);
}

void pulseRelay(int pin, int timeMs = PULSE_TIME) {
  digitalWrite(pin, LOW);
  delay(relayPulseMs);          // default same as PULSE_TIME
  digitalWrite(pin, HIGH);
  Serial.printf("Relay %d pulsed for %d ms\n", pin, relayPulseMs);
}

// ================= Preferences Helpers =================
void loadSavedSettings() {
  preferences.begin("wifi", true);
  wifi_ssid = preferences.getString("ssid", "");
  wifi_pass = preferences.getString("pass", "");
  preferences.end();

  preferences.begin("ap", true);
  ap_name = preferences.getString("apname", "");
  ap_pass = preferences.getString("appass", "");
  preferences.end();
}

void saveWifiCredentials(const String &s, const String &p) {
  preferences.begin("wifi", false);
  preferences.putString("ssid", s);
  preferences.putString("pass", p);
  preferences.end();
}

void saveApCredentials(const String &name, const String &pass) {
  preferences.begin("ap", false);
  preferences.putString("apname", name);
  preferences.putString("appass", pass);
  preferences.end();
}

void clearAllCredentials() {
  preferences.begin("wifi", false); preferences.clear(); preferences.end();
  preferences.begin("ap", false);   preferences.clear(); preferences.end();
}

// --------- ADDED ---------
void loadRelayPulseTime() {
  preferences.begin("settings", true);
  relayPulseMs = preferences.getInt("pulseMs", PULSE_TIME);
  preferences.end();
  if (relayPulseMs < 1000 || relayPulseMs > 5000)
    relayPulseMs = PULSE_TIME;
}

void saveRelayPulseTime(int ms) {
  preferences.begin("settings", false);
  preferences.putInt("pulseMs", ms);
  preferences.end();
}
// -------------------------

// ================= Preferences (Auto Mode) =================
void restoreAutoMode() {
  preferences.begin("settings", true);
  autoMode = preferences.getBool("autoMode", false);
  preferences.end();

  digitalWrite(AUTO_MODE_LED, autoMode ? HIGH : LOW);

  if (autoMode) {
    // ---- 60 SECOND DELAY RESTORED ----
    Serial.println("Power Reset: Auto Mode is ON. Waiting 60s...");
    delay(AUTO_DELAY); 
    // ----------------------------------
    
    pulseRelay(RELAY1_PIN);

    if (WiFi.status() == WL_CONNECTED && SinricPro.isConnected()) {
      SinricProSwitch &sw1 = SinricPro[DEVICE_ID_1];
      sw1.sendPowerStateEvent(true);
      delay(300);
      sw1.sendPowerStateEvent(false);
    }
  }
}

// ================= Sinric Pro =================
bool onPowerState(const String &deviceId, bool &state) {
  if (deviceId == DEVICE_ID_1) pulseRelay(RELAY1_PIN);
  else if (deviceId == DEVICE_ID_2) pulseRelay(RELAY2_PIN);
  else if (deviceId == DEVICE_ID_3) {
    autoMode = state;
    preferences.begin("settings", false);
    preferences.putBool("autoMode", autoMode);
    preferences.end();
    digitalWrite(AUTO_MODE_LED, autoMode ? HIGH : LOW);
  }
  return true;
}

void setupSinricPro() {
  SinricProSwitch &sw1 = SinricPro[DEVICE_ID_1];
  SinricProSwitch &sw2 = SinricPro[DEVICE_ID_2];
  SinricProSwitch &sw3 = SinricPro[DEVICE_ID_3];

  sw1.onPowerState(onPowerState);
  sw2.onPowerState(onPowerState);
  sw3.onPowerState(onPowerState);

  SinricPro.restoreDeviceStates(false);
  SinricPro.begin(APP_KEY, APP_SECRET);
}

// ================= WiFi Scan (ADDED, NON-BLOCKING) =================
String escapeHTML(const String &s) {
  String r = s;
  r.replace("&","&amp;");
  r.replace("<","&lt;");
  r.replace(">","&gt;");
  r.replace("\"","&quot;");
  r.replace("'","&#39;");
  return r;
}

void scanWiFiOnce() {
  WiFi.scanDelete();
  wifiScanCount = WiFi.scanNetworks();
}

String buildWifiOptions(String current) {
  String opt = "";
  for (int i = 0; i < wifiScanCount; i++) {
    String s = WiFi.SSID(i);
    opt += "<option value='" + escapeHTML(s) + "'";
    if (s == current) opt += " selected";
    opt += ">" + escapeHTML(s) + "</option>";
  }
  return opt;
}

// ================= Web Page (Captive Portal) =================
void handleControlPage() {
  String curApName = ap_name.length() ? ap_name : DEFAULT_AP_NAME;
  String curApPass = ap_pass.length() ? ap_pass : DEFAULT_AP_PASS;
  String curWifi   = wifi_ssid;

  String html = "<!doctype html><html><head><meta charset='UTF-8'><meta name='viewport' content='width=device-width, initial-scale=1'>";
  html += "<style>body{font-family:Arial;text-align:center;background:#eef2ff;padding:8px;}button,input,select{padding:12px;margin:6px;width:90%;font-size:16px;border:none;border-radius:8px;}h1{color:#002b80;}</style>";

  html += "<script>"
          "function flashRedirect(btn, url){"
          "var o=btn.style.backgroundColor||'';"
          "btn.style.backgroundColor='#FFD700';"
          "setTimeout(function(){location.href=url;},100);"
          "setTimeout(function(){btn.style.backgroundColor=o;},200);"
          "}"
          "</script>";

  html += "</head><body><h1>Pump Controller</h1><h3>Local Wifi AP Settings</h3>";
  html += "<form action='/save' method='POST'>";

  html += "<input name='apname' placeholder='AP Name' value='"+escapeHTML(curApName)+"'><br>";
  html += "<input name='apass' placeholder='AP Password' value='"+escapeHTML(curApPass)+"'><br>";

  html += "<h3>Home WiFi (for Internet)</h3>";

  html += "<select name='ssid_select'>";
  html += "<option value=''>-- Select Nearby WiFi (optional) --</option>";
  html += buildWifiOptions(curWifi);
  html += "</select><br>";

  html += "<input name='ssid' placeholder='WiFi SSID' value='"+escapeHTML(curWifi)+"'><br>";
  html += "<input name='pass' type='password' placeholder='WiFi Password'><br>";

  html += "<h3>Relay Trigger Time</h3><select name='pulse'>";
  for (int i = 1; i <= 5; i++) {
    int ms = i * 1000;
    html += "<option value='"+String(ms)+"'";
    if (relayPulseMs == ms) html += " selected";
    html += ">"+String(i)+" Second</option>";
  }
  html += "</select><br>";

  html += "<button style='background:#007BFF;color:white;'>Save Settings (AP + WiFi)</button></form><hr>";

  html += "<h3>Manual Local Wifi Control</h3>";
  html += "<button style='background:#4CAF50;color:white;' onclick=\"flashRedirect(this,'/relay1')\">Start Pump</button><br>";
  html += "<button style='background:#f44336;color:white;' onclick=\"flashRedirect(this,'/relay2')\">Stop Pump</button><br>";

  html += autoMode
    ? "<button style='background:#2196F3;color:white;' onclick=\"flashRedirect(this,'/auto/off')\">Disable Auto Mode</button>"
    : "<button style='background:#2196F3;color:white;' onclick=\"flashRedirect(this,'/auto/on')\">Enable Auto Mode</button>";

  html += "<p><b>Auto Mode:</b> "+String(autoMode?"Enabled":"Disabled")+"</p>";
  html += "<p>WiFi Status: "+String(WiFi.status()==WL_CONNECTED?"Connected":"Not Connected / AP Mode")+"</p>";
  html += "<p><small>To restore factory AP & clear credentials press BOOT button >5s</small></p>";

  html += "</body></html>";
  server.send(200,"text/html",html);
}

// ================= Web Handlers =================
void handleRelay1() {
  pulseRelay(RELAY1_PIN);
  if (WiFi.status()==WL_CONNECTED) {
    SinricProSwitch &sw1 = SinricPro[DEVICE_ID_1];
    sw1.sendPowerStateEvent(true); delay(300); sw1.sendPowerStateEvent(false);
  }
  server.sendHeader("Location","/",true);
  server.send(302,"");
}

void handleRelay2() {
  pulseRelay(RELAY2_PIN);
  if (WiFi.status()==WL_CONNECTED) {
    SinricProSwitch &sw2 = SinricPro[DEVICE_ID_2];
    sw2.sendPowerStateEvent(true); delay(300); sw2.sendPowerStateEvent(false);
  }
  server.sendHeader("Location","/",true);
  server.send(302,"");
}

void handleAutoOn() {
  autoMode=true;
  preferences.begin("settings",false);
  preferences.putBool("autoMode",true);
  preferences.end();
  digitalWrite(AUTO_MODE_LED,HIGH);
  if (WiFi.status()==WL_CONNECTED) {
    SinricProSwitch &sw3 = SinricPro[DEVICE_ID_3];
    sw3.sendPowerStateEvent(true);
  }
  server.sendHeader("Location","/",true);
  server.send(302,"");
}

void handleAutoOff() {
  autoMode=false;
  preferences.begin("settings",false);
  preferences.putBool("autoMode",false);
  preferences.end();
  digitalWrite(AUTO_MODE_LED,LOW);
  if (WiFi.status()==WL_CONNECTED) {
    SinricProSwitch &sw3 = SinricPro[DEVICE_ID_3];
    sw3.sendPowerStateEvent(false);
  }
  server.sendHeader("Location","/",true);
  server.send(302,"");
}

void registerWebHandlers() {
  server.on("/generate_204", [](){ handleControlPage(); });
  server.on("/hotspot-detect.html", [](){ handleControlPage(); });
  server.on("/connecttest.txt", [](){ handleControlPage(); });

  server.on("/", handleControlPage);
  server.on("/relay1", handleRelay1);
  server.on("/relay2", handleRelay2);
  server.on("/auto/on", handleAutoOn);
  server.on("/auto/off", handleAutoOff);

  server.on("/save", HTTP_POST, [](){
    bool changed=false;

    if (server.hasArg("apname") && server.arg("apname").length()) {
      ap_name=server.arg("apname");
      saveApCredentials(ap_name, ap_pass);
      changed=true;
    }
    if (server.hasArg("apass") && server.arg("apass").length()) {
      ap_pass=server.arg("apass");
      saveApCredentials(ap_name, ap_pass);
      changed=true;
    }

    if (server.hasArg("ssid_select") && server.arg("ssid_select").length()) {
      wifi_ssid=server.arg("ssid_select");
      saveWifiCredentials(wifi_ssid, wifi_pass);
      changed=true;
    }
    else if (server.hasArg("ssid") && server.arg("ssid").length()) {
      wifi_ssid=server.arg("ssid");
      saveWifiCredentials(wifi_ssid, wifi_pass);
      changed=true;
    }

    if (server.hasArg("pass") && server.arg("pass").length()) {
      wifi_pass=server.arg("pass");
      saveWifiCredentials(wifi_ssid, wifi_pass);
      changed=true;
    }

    if (server.hasArg("pulse")) {
      int ms=server.arg("pulse").toInt();
      if (ms>=1000 && ms<=5000) {
        relayPulseMs=ms;
        saveRelayPulseTime(ms);
        changed=true;
      }
    }

    if (!changed) {
      server.send(400,"text/html","<h2 style='color:red;'>No values provided.</h2>");
      return;
    }

    server.send(200,"text/html","<h2 style='color:blue;'>Saved! Restarting...</h2>");
    delay(1500);
    ESP.restart();
  });

  server.onNotFound([](){
    if (!isIp(server.hostHeader())) {
      server.sendHeader("Location","http://192.168.4.1",true);
      server.send(302,"");
      return;
    }
    handleControlPage();
  });
}

// ================= AP Mode =================
void startAPMode(const char* apName,const char* apPass) {
  WiFi.mode(WIFI_AP_STA);
  // Stable AP Fix: Set Static Gateway
  WiFi.softAPConfig(apIP, apIP, netMsk);
  WiFi.softAP(apName, apPass);
  
  // CRITICAL FIX: Disable WiFi sleep to keep AP stable
  WiFi.setSleep(false); 

  dnsServer.start(DNS_PORT, "*", apIP);
  registerWebHandlers();
  server.begin();
  apModeActive=true;
  digitalWrite(WIFI_LED_PIN,LOW);
}

// ================= WiFi Handling =================
void connectToWiFiAndStartAP() {
  loadSavedSettings();

  String useAPName = ap_name.length()?ap_name:DEFAULT_AP_NAME;
  String useAPPass = ap_pass.length()?ap_pass:DEFAULT_AP_PASS;

  startAPMode(useAPName.c_str(), useAPPass.c_str());
  scanWiFiOnce();

  if (wifi_ssid.length() && wifi_pass.length()) {
    WiFi.begin(wifi_ssid.c_str(), wifi_pass.c_str());
  }
}

// ================= Setup =================
void setup() {
  Serial.begin(115200);
  pinMode(WIFI_LED_PIN, OUTPUT);
  digitalWrite(WIFI_LED_PIN, LOW);
  pinMode(AUTO_MODE_LED, OUTPUT);
  pinMode(MANUAL_BTN_PIN, INPUT_PULLUP);
  pinMode(BOOT_BTN_PIN, INPUT_PULLUP);
  pinMode(AUTO_TOGGLE_BTN, INPUT_PULLUP);

  setupRelay(RELAY1_PIN);
  setupRelay(RELAY2_PIN);

  loadRelayPulseTime();
  
  // Stability Fix: Start WiFi/AP first, then do the 60s Delay
  connectToWiFiAndStartAP(); 
  
  ArduinoOTA.setHostname("PumpController_OTA");
  ArduinoOTA.begin();
  setupSinricPro();
  
  restoreAutoMode(); // This will trigger the 60s delay if autoMode is ON
}

// ================= Loop =================
void loop() {
  ArduinoOTA.handle();
  SinricPro.handle();
  server.handleClient();
  if (apModeActive) dnsServer.processNextRequest();

  // Manual Auto toggle
  if (digitalRead(AUTO_TOGGLE_BTN) == LOW) {
    autoMode = !autoMode;
    digitalWrite(AUTO_MODE_LED, autoMode ? HIGH : LOW);
    preferences.begin("settings", false);
    preferences.putBool("autoMode", autoMode);
    preferences.end();

    if (WiFi.status()==WL_CONNECTED && SinricPro.isConnected()) {
      SinricProSwitch &sw3 = SinricPro[DEVICE_ID_3];
      sw3.sendPowerStateEvent(autoMode);
    }
    delay(200);
    while(digitalRead(AUTO_TOGGLE_BTN)==LOW) delay(10);
  }

  // Manual stop button
  if (digitalRead(MANUAL_BTN_PIN)==LOW) {
    if (!btnPressed) { btnPressed=true; btnPressStart=millis(); }
    else if (millis()-btnPressStart>=HOLD_TIME) {
      pulseRelay(RELAY2_PIN);
      if (WiFi.status()==WL_CONNECTED && SinricPro.isConnected()) {
        SinricProSwitch &sw2 = SinricPro[DEVICE_ID_2];
        sw2.sendPowerStateEvent(true); delay(300); sw2.sendPowerStateEvent(false);
      }
      btnPressed=false;
      while(digitalRead(MANUAL_BTN_PIN)==LOW) delay(10);
    }
  } else btnPressed=false;

  // Boot reset
  if (digitalRead(BOOT_BTN_PIN)==LOW) {
    if (!bootBtnPressed) { bootBtnPressed=true; bootBtnStart=millis(); }
    else if (millis()-bootBtnStart>=HOLD_TIME) {
      clearAllCredentials();
      delay(500);
      ESP.restart();
    }
  } else bootBtnPressed=false;

  // WiFi reconnect
  if (WiFi.status()!=WL_CONNECTED && millis()-lastReconnectAttempt>10000) {
    if (wifi_ssid.length() && wifi_pass.length())
      WiFi.begin(wifi_ssid.c_str(), wifi_pass.c_str());
    lastReconnectAttempt=millis();
  }

  digitalWrite(WIFI_LED_PIN, (WiFi.status() == WL_CONNECTED) ? HIGH : LOW);
}